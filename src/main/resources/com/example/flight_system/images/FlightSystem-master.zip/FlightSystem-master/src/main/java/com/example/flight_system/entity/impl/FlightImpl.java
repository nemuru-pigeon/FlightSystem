package com.example.flight_system.entity.impl;

import com.example.flight_system.entity.FlightType;

public interface FlightImpl {
    FlightType getType();
}
