package com.example.flight_system.entity.impl;

import java.util.Date;

public interface PaymentImpl {
    String getId();
    String getDetail();
    Date getDate();
    float getPrice();
}
