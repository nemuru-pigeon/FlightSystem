package com.example.flight_system.entity.impl;

public interface MealImpl {
    String getId();
}
