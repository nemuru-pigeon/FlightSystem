package com.example.flight_system.control.impl;

import java.util.Map;

public interface InputControlImpl {
    Map<String, String> readIdCard();
}
