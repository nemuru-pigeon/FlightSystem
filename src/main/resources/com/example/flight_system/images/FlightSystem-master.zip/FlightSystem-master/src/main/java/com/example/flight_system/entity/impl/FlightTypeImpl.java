package com.example.flight_system.entity.impl;

public interface FlightTypeImpl {
    int[][] getStructure();
}
