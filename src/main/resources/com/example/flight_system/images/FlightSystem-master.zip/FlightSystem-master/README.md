# FlightSystem
description:
---
This is a respository for the group project in EBU6304 - SOFTWARE ENGINEERING.  
This is a flight check-in system based on EBC(Entity-Boundary-Control) pattern.

注意事项（看这里！！！）：
---
1. git的相关教程网上有很多，希望大家能自主学习，参考教程：https://blog.csdn.net/a749402932/article/details/107148373/ ，里面提到的配置Git路径是指你下载的Git客户端的路径，客户端可以去官网下载：https://git-scm.com/
2. 写代码时，推荐大家在本地创建自己的分支，新内容在自己的分支上写，这样提交前可以先在主分支上更新，再将自己的分支合并上去，方便解决可能存在的冲突，最后提交到git上。
3. 之前的总结，方便你们查看：  
环境：idea  
界面实现：javafx，该平台实现界面的方式是fxml（类似于html）+control类，例子：https://blog.csdn.net/baidu_30325009/article/details/93321504 （如何切换界面）
